package com.cts.couriertrackingsystem.dao;

import com.cts.couriertrackingsystem.model.Admin;

public interface AdminDAO {

	public Admin getAdmin(Admin a);

	public Long insertAdmin(Admin a);

}
